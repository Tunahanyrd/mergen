# 🌐 Mergen Browser Extension - Kurulum Rehberi

## Chrome / Chromium için Kurulum

### Adım 1: Extension Dosyasını İndir
Extension zaten hazır:
```
~/Masaüstü/mergen/browser-extension/
```

### Adım 2: Chrome Extensions Sayfasını Aç
1. Chrome'u aç
2. Adres çubuğuna yaz: `chrome://extensions/`
3. **Enter** tuşuna bas

### Adım 3: Developer Mode'u Aç
- Sağ üstte **"Developer mode"** toggle'ını **AÇ** (mavi olmalı)

### Adım 4: Extension'ı Yükle
1. **"Load unpacked"** butonuna tıkla
2. Şu klasörü seç: `/home/tunahan/Masaüstü/mergen/browser-extension/`
3. **"Select Folder"** tıkla

✅ Extension yüklendi!

### Adım 5: Extension ID'yi Kopyala
1. Extension listesinde **"Mergen Download Manager"** bulun
2. İsmin **altında** uzun bir kod var (örnek: `abcdefgh...`)
3. Bu kodu **KOPYALA** (seç + Ctrl+C)

### Adım 6A: GUI ile Kaydet (Kolay)
1. **Mergen uygulamasını** aç
2. **Settings** → **Browser Integration** tab'ına git
3. Extension ID'yi **yapıştır** (Ctrl+V)
4. **"Register"** butonuna tıkla
5. ✅ **Bitti!**

### Adım 6B: CLI ile Kaydet (Alternatif)
Terminal'de:
```bash
cd ~/Masaüstü/mergen
./quick-register.sh KOPYALADIGIN_EXTENSION_ID
```

### Adım 7: Extension'ı Reload Et
1. `chrome://extensions/` sayfasında
2. Mergen extension'ında **🔄 Reload** butonuna tıkla

### Adım 8: Test Et! 🎉
**A) Context Menu:**
- Herhangi bir link'e **sağ tıkla**
- **"Download with Mergen"** seç
- Mergen'de notification + indirme başlar!

**B) Direct Download:**
- Herhangi bir dosya linkine **tıkla**
- Chrome indirmez, Mergen yakalar!

---

## Zen Browser (Firefox-based) için Kurulum

### Adım 1: About Debugging Sayfasını Aç
1. Zen Browser'ı aç
2. Adres çubuğuna yaz: `about:debugging#/runtime/this-firefox`
3. **Enter** bas

### Adım 2: Temporary Add-on Yükle
1. **"Load Temporary Add-on..."** butonuna tıkla
2. Şu dosyayı seç: `/home/tunahan/Masaüstü/mergen/browser-extension/manifest.json`
3. **"Open"** tıkla

✅ Extension yüklendi!

### Adım 3: Extension ID'yi Kopyala
1. Extension popup'ını aç (toolbar'daki Mergen icon'a tıkla)
2. Extension ID gösterilir
3. **📋 Copy** butonuna tıkla

### Adım 4: Mergen'de Kaydet
1. **Mergen uygulamasını** aç
2. **Settings** → **Browser Integration**
3. Extension ID'yi yapıştır → **Register**

### Adım 5: Test Et!
- Bir link'e sağ tıkla → **"Download with Mergen"**

---

## 🐛 Sorun Giderme

### "Access to specified native messaging host is forbidden"
**Çözüm:** Extension ID kayıtlı değil
1. Extension ID'yi tekrar kopyala
2. Mergen Settings'te tekrar kaydet
3. Extension'ı reload et

### "Native messaging host not found"
**Çözüm:** Native host kurulu değil
```bash
cd ~/Masaüstü/mergen/native-host
./install-no-sudo.sh
```

### Extension yüklenmiyor
**Çözüm:** Manifest hatası olabilir
1. `chrome://extensions/` → **Details** → **Errors** kontrol et
2. Hata varsa bana söyle!

### Download yakalanmıyor
**Kontroller:**
1. ✅ Extension yüklü mü?
2. ✅ Extension ID kayıtlı mı?
3. ✅ Mergen çalışıyor mu?
4. ✅ Log'da hata var mı? (`tail -f ~/.mergen-native-host.log`)

---

## 📝 Özet

```
1. Chrome: chrome://extensions/ → Load unpacked
2. Extension ID'yi kopyala
3. Mergen Settings → Yapıştır → Register
4. Chrome'da Reload
5. Test et!
```

**İşte bu kadar! 🎉**
