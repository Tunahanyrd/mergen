# Mergen Browser Extension - POC Test Guide

## 🎯 Testing the POC

### Step 1: Install Native Host

```bash
cd /home/tunahan/Masaüstü/mergen/native-host
./install.sh
```

### Step 2: Load Extension in Chrome

1. Open Chrome/Chromium
2. Go to `chrome://extensions/`
3. Enable "Developer mode" (top right)
4. Click "Load unpacked"
5. Select: `/home/tunahan/Masaüstü/mergen/browser-extension/`

### Step 3: Get Extension ID

1. Find "Mergen Download Manager" in `chrome://extensions/`
2. Copy the Extension ID (looks like: `abcdefghijklmnopqrstuvwxyz123456`)

### Step 4: Update Native Host Manifest

```bash
# Edit the manifest file
nano ~/.config/google-chrome/NativeMessagingHosts/com.tunahanyrd.mergen.json

# OR for Chromium:
nano ~/.config/chromium/NativeMessagingHosts/com.tunahanyrd.mergen.json

# Replace: "chrome-extension://EXTENSION_ID_PLACEHOLDER/"
# With:    "chrome-extension://YOUR_ACTUAL_EXTENSION_ID/"
```

### Step 5: Test!

**Test 1: Context Menu**
1. Right-click any link on a webpage
2. Select "Download with Mergen"
3. Check log: `tail -f ~/.mergen-native-host.log`
4. You should see: "🔽 DOWNLOAD CAPTURED!" with URL

**Test 2: Direct Download**
1. Click any download link
2. Browser will try to download
3. Extension intercepts it
4. Check log for captured URL

## ✅ Success Criteria

If you see this in the log:
```
🔽 DOWNLOAD CAPTURED!
   URL: https://example.com/file.zip
   Filename: file.zip
```

**🎉 POC WORKS! Native Messaging is functional!**

## 🐛 Troubleshooting

**Error: "Native messaging host not found"**
- Run `./install.sh` again
- Check manifest location: `~/.config/google-chrome/NativeMessagingHosts/`
- Verify extension ID in manifest matches actual ID

**No log output:**
- Check Python script is executable: `ls -l native-host/mergen-native-host.py`
- Check log file exists: `ls -la ~/.mergen-native-host.log`
- Try running script manually: `echo '{"test": true}' | ./native-host/mergen-native-host.py`

**Extension not loading:**
- Check manifest.json syntax
- Check Chrome console for errors
- Reload extension after changes

## 📊 What to Look For

✅ **Extension loads** without errors  
✅ **Context menu** appears on right-click  
✅ **Log file** shows messages when downloading  
✅ **URL is captured** correctly  

## 🚀 Next Steps (if POC succeeds)

1. Add Mergen IPC integration (DBus/Socket)
2. Send downloads to running Mergen instance
3. Build full extension UI
4. Add settings page
5. Package for distribution

---

**Current Status**: POC Testing Phase  
**Log Location**: `~/.mergen-native-host.log`
